## makeCacheMatrix will create a matrix object that can cache its inverse.

makeCacheMatrix <- function(x = matrix()) {
      m <- NULL
      setmatrix <- function(y) {
                x <<- y
                m <<- NULL
      }
      getmatrix <- function() x
      setinverse <- function(solveforinverse) inverse <<- solveforinverse
      getinverse <- function() inverse
      list(setmatrix = setmatrix,
           getmatrix = getmatrix,
           setinverse = setinverse,
           getinverse = getinverse)
}

## CacheSolve will compute the inverse of the matrix derived from makeCacheMatrix,
## If the inverse has already been computed, it will simply retrieve the matrix
## from the cache.

cacheSolve <- function(x, ...) {
        inverse <- x$getinverse
        if (!is.null(inverse)) {
                message("The cache's inverse has already been solved. Retrieving cache.")
                return(inverse)
        }
        data <- x$getmatrix()
        inverse <- solve(data)
        x$setinverse(inverse)
        inverse
}